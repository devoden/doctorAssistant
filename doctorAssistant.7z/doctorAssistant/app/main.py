from models.hospital import Hospital
from repos.hospitals import Hospitals


if __name__ == '__main__':
    try:
        data_manager1 = Hospitals(Hospital())
        data_manager1.display_all_hospitals()
    except RecursionError as rte:
        print(rte)
